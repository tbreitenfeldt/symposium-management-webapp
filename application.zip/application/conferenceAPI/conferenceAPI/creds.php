<?php
//Ignore this file. The correct file should be in the databaseUtil folder.
define("DB_NAME", "seniorcapstonedev");
define("DB_HOST", "localhost");
define("DB_USERNAME", "root");
DEFINE("DB_PASSWORD", "");
define("DB_CHARSET", "utf8mb4");
define("DSN", "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET . ";");
?>
