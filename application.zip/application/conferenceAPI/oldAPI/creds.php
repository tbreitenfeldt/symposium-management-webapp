<?php
	$host="mysql5006.site4now.net";
	$db="Db_a444c6_senior";
	$charset="utf8mb4";
	$user="a444c6_senior";
	$pw="seniorTeam4";
	$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
?>