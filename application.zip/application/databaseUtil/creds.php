<?php
define("DB_NAME", "Db_a444c6_senior");
define("DB_HOST", "mysql5006.site4now.net");
define("DB_USERNAME", "a444c6_senior");
DEFINE("DB_PASSWORD", "seniorTeam4");
define("DB_CHARSET", "utf8mb4"); 
?>