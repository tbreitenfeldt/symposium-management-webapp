
    <div id="innerContent" role="main" tabindex="-1">
        <h2 id="conferenceInformationHeader"></h2>

        <div id="details"></div>
    </div>