
<div id="innerContent" role="main" tabindex="-1">
    <div id="conferenceChooser">
        <h2 id="conferenceRegistrationHeading">Conference Registration</h2>    
        <label for="conferenceChooser">Select a conference to register for</label>
        <select id="conferenceChooserListbox"></select>
        <input type="button" id ="conferenceRegisterButton" value="Register for Conference" />
    </div>
</div>