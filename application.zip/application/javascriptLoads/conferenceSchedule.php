
<div id="innerContent" role="main" tabindex="-1">
    <div id="conference-table">
        <h2 id="conferenceNameHeader">Conference Schedule</h2>
        <div id="MainConference">
            <table id="Conference">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Time Start</th>
                    <th>Time End</th>
                    <th colspan="2">Actions</th>
                </tr>
                </thead>
                <tbody id="conferenceBody">
                </tbody>
            </table>
        </div>
    </div>
</div>
