<?php ?>

    <div id="innerContent">
        <h1> <center> Conference Information </center></h1>
        <div id="details">
            <center><p id="description"></p></center>

            <header> Location: </header>
            <p id="location"></p>
            
            <header> Contact us: </header>
            <p id="contact"></p>
        </div>
    </div>