
<div id="innerContent" role="main" tabindex="-1">
    <div id="schedule-table">
            <h1>My Schedule</h1>
                <div id="UserConference">
                    <table id="myScheduleTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Date</th>
                                <th>Time Start</th>
								<th>Time End</th>
                                <th colspan=2>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="schedInfo">
                        </tbody>
                    </table>
                </div>
    </div>